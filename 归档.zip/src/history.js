import { createBrowserHistory } from 'history';
export default createBrowserHistory(); 

// import { createHashHistory } from 'history';
// export default createHashHistory(); 